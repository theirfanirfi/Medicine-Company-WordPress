ace.define('ace/snippets/nix', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "nix";

});
