ace.define('ace/snippets/ini', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "ini";

});
