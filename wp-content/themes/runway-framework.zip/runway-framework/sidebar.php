<?php

// This file servers no purpose other than being a placeholder. 
// It's here so that you don't get junk WP content if a rogue plugin makes a random call to "get_sidebar()"