<script id="field-settings-preview" type="text/x-jquery-tmpl">
	<p class="settings-preview-raw">
		<strong><label class="settings-preview-label">${label}</label></strong>&nbsp;
		<span class="settings-preview-value">${value}</span>
	</p>
</script>
