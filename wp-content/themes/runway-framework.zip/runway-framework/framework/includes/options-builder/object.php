<?php
/**
 * Apm_Settings_Object
 *
 *
 * @category Options pages
 * @package  Core estensions
 * @author    <>
 * @license
 * @link
 */
class Apm_Settings_Object {

	function __construct() {
		//
	}

}

?>
