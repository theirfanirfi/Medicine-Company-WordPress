<?php
class Reports_Object extends Runway_Object {	

	function __construct( $settings ) {
		//
	}	

}
?>
