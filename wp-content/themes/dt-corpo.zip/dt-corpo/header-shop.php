<?php
/**
 * The header for woocommerce shop
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage DT_Corpo
 * @since 1.0
 * @version 1.0
 */
get_header();
do_action( 'dt_corpo_wc_wapper_start' );
?>